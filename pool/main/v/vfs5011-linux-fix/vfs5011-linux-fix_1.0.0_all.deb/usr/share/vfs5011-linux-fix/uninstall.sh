#!/usr/bin/env bash
#
# Validity VFS5011 Driver Revert Script
#
set -euo pipefail

BACKUP_DIR="/var/backups/libfprint-vfs5011-stock"
STOCK_LIB="$BACKUP_DIR/libfprint-2.so.2.0.0.stock"

SUDO=""
if [ "$EUID" -ne 0 ]; then
    SUDO="sudo"
fi

# Find system library directory
LIB_DIR=""
for candidate in \
    "/usr/lib/x86_64-linux-gnu" \
    "/usr/lib64" \
    "/usr/lib"; do
    if [ -f "$candidate/libfprint-2.so.2" ]; then
        LIB_DIR="$candidate"
        break
    fi
done

if [ ! -f "$STOCK_LIB" ]; then
    echo "No stock backup found at $STOCK_LIB."
    echo "To restore stock package, you can run:"
    echo "  sudo apt-get --reinstall install libfprint-2-2 (Debian/Ubuntu)"
    echo "  sudo dnf reinstall libfprint (Fedora)"
    echo "  sudo pacman -S libfprint (Arch)"
    exit 1
fi

echo "Stopping fprintd service..."
$SUDO systemctl stop fprintd 2>/dev/null || true

echo "Restoring stock library to $LIB_DIR..."
$SUDO cp -v "$STOCK_LIB" "$LIB_DIR/libfprint-2.so.2.0.0"
$SUDO ln -sf libfprint-2.so.2.0.0 "$LIB_DIR/libfprint-2.so.2"
$SUDO ldconfig

echo "Restarting fprintd..."
$SUDO systemctl restart fprintd

echo "Reverted back to distribution stock driver successfully."
