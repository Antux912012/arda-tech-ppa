#!/usr/bin/env bash
#
# Validity VFS5011 (138a:0011) Automated Linux Driver Fix
# Author: Antonio & DeepMind Antigravity Pair Programming
# Works on: Debian, Ubuntu, Linux Mint, Fedora, Arch Linux
#
set -euo pipefail

BOLD="\033[1m"
GREEN="\033[0;32m"
YELLOW="\033[1;33m"
RED="\033[0;31m"
RESET="\033[0m"

log_info()  { echo -e "${GREEN}[+]${RESET} ${BOLD}$1${RESET}"; }
log_warn()  { echo -e "${YELLOW}[!]${RESET} $1"; }
log_error() { echo -e "${RED}[x]${RESET} $1"; }

echo -e "${BOLD}======================================================${RESET}"
echo -e "${BOLD}   Validity VFS5011 Linux Driver Fix & Installer      ${RESET}"
echo -e "${BOLD}======================================================${RESET}"

# 1. Check for root privileges
SUDO=""
if [ "$EUID" -ne 0 ]; then
    if command -v sudo >/dev/null 2>&1; then
        SUDO="sudo"
    else
        log_error "This script requires superuser privileges. Run as root or install sudo."
        exit 1
    fi
fi

# 2. Check for device presence
log_info "Detecting Validity Sensors hardware..."
if lsusb | grep -qiE "138a:0011|138a:0010|138a:0015|138a:0017|138a:0018"; then
    SENSOR_LINE=$(lsusb | grep -iE "138a:0011|138a:0010|138a:0015|138a:0017|138a:0018")
    log_info "Found supported sensor: $SENSOR_LINE"
else
    log_warn "No 138a:0011/0017/0018 sensor detected via lsusb."
    read -rp "Continue installation anyway? [y/N]: " CONFIRM
    if [[ ! "$CONFIRM" =~ ^[yY]$ ]]; then
        exit 0
    fi
fi

# 3. Detect Package Manager & Install Dependencies
log_info "Installing build dependencies..."
if command -v apt-get >/dev/null 2>&1; then
    $SUDO apt-get update
    $SUDO apt-get install -y \
        meson ninja-build gcc git pkg-config \
        libusb-1.0-0-dev libglib2.0-dev libpixman-1-dev \
        libnss3-dev libgusb-dev libgudev-1.0-dev \
        fprintd libpam-fprintd
elif command -v dnf >/dev/null 2>&1; then
    $SUDO dnf install -y \
        meson ninja-build gcc git pkgconf-pkg-config \
        libusb1-devel glib2-devel pixman-devel \
        nss-devel libgusb-devel libgudev-devel \
        fprintd fprintd-pam
elif command -v pacman >/dev/null 2>&1; then
    $SUDO pacman -Sy --noconfirm \
        meson ninja gcc git pkgconf \
        libusb glib2 pixman nss libgusb libgudev \
        fprintd
else
    log_warn "Unrecognized package manager. Ensure meson, ninja, gcc, git, and libusb/glib dev headers are installed."
fi

# 4. Determine system library location
LIB_DIR=""
for candidate in \
    "/usr/lib/x86_64-linux-gnu" \
    "/usr/lib64" \
    "/usr/lib" \
    "/usr/local/lib"; do
    if [ -f "$candidate/libfprint-2.so.2" ] || [ -f "$candidate/libfprint-2.so" ]; then
        LIB_DIR="$candidate"
        break
    fi
done

if [ -z "$LIB_DIR" ]; then
    if [ -d "/usr/lib/x86_64-linux-gnu" ]; then
        LIB_DIR="/usr/lib/x86_64-linux-gnu"
    else
        LIB_DIR="/usr/lib"
    fi
fi
log_info "Target system library directory: $LIB_DIR"

# 5. Prepare workspace
BUILD_DIR="${HOME}/.cache/libfprint-vfs5011-build"
mkdir -p "$BUILD_DIR"
cd "$BUILD_DIR"

if [ ! -d "libfprint/.git" ]; then
    log_info "Cloning upstream libfprint repository..."
    git clone https://gitlab.freedesktop.org/libfprint/libfprint.git libfprint
fi

cd libfprint
git checkout master
git fetch origin
git reset --hard origin/master

# 6. Apply Patches
log_info "Applying VFS5011 driver fixes..."

patch -p1 << 'EOF'
diff --git a/libfprint/drivers/vfs5011.c b/libfprint/drivers/vfs5011.c
index b9e0587b..bf39cf4d 100644
--- a/libfprint/drivers/vfs5011.c
+++ b/libfprint/drivers/vfs5011.c
@@ -272,6 +272,7 @@ struct _FpDeviceVfs5011
   int                     lines_total, lines_total_allocated;
   gboolean                loop_running;
   gboolean                deactivating;
+  gboolean                activated;
   struct usbexchange_data init_sequence;
 };
 
@@ -314,8 +315,8 @@ process_chunk (FpDeviceVfs5011 *self, int transferred)
 {
   enum {
     DEVIATION_THRESHOLD = 15 * 15,
-    DIFFERENCE_THRESHOLD = 600,
-    STOP_CHECK_LINES = 50
+    DIFFERENCE_THRESHOLD = 350,
+    STOP_CHECK_LINES = 80
   };
 
   fp_dbg ("process_chunk: got %d bytes", transferred);
@@ -382,7 +383,7 @@ submit_image (FpiSsm          *ssm,
 {
   FpImage *img;
 
-  if (self->lines_recorded < VFS5011_IMAGE_WIDTH)
+  if (self->lines_recorded < 40)
     {
       fpi_image_device_retry_scan (dev, FP_DEVICE_RETRY_TOO_SHORT);
       return;
@@ -454,8 +455,8 @@ capture_chunk_async (FpDeviceVfs5011 *self,
           nline, self->lines_recorded);
   enum {
     DEVIATION_THRESHOLD = 15 * 15,
-    DIFFERENCE_THRESHOLD = 600,
-    STOP_CHECK_LINES = 50
+    DIFFERENCE_THRESHOLD = 350,
+    STOP_CHECK_LINES = 80
   };
 
   transfer = fpi_usb_transfer_new (FP_DEVICE (self));
@@ -694,7 +695,11 @@ activate_loop (FpiSsm *ssm, FpDevice *_dev)
         g_free (self->init_sequence.receive_buf);
       self->init_sequence.receive_buf = NULL;
       capture_init (self, MAX_CAPTURE_LINES, MAXLINES);
-      fpi_image_device_activate_complete (dev, NULL);
+      if (!self->activated)
+        {
+          self->activated = TRUE;
+          fpi_image_device_activate_complete (dev, NULL);
+        }
       fpi_ssm_next_state (ssm);
       break;
 
@@ -797,10 +802,14 @@ dev_open (FpImageDevice *dev)
   GError *error = NULL;
   FpDeviceVfs5011 *self;
 
+  GUsbDevice *usb_dev = fpi_device_get_usb_device (FP_DEVICE (dev));
+
   self = FPI_DEVICE_VFS5011 (dev);
   self->capture_buffer = g_new0 (unsigned char, CAPTURE_LINES * VFS5011_LINE_SIZE);
 
-  if (!g_usb_device_claim_interface (fpi_device_get_usb_device (FP_DEVICE (dev)), 0, 0, &error))
+  g_usb_device_reset (usb_dev, NULL);
+
+  if (!g_usb_device_claim_interface (usb_dev, 0, 0, &error))
     {
       fpi_image_device_open_complete (dev, error);
       return;
@@ -815,12 +824,19 @@ dev_close (FpImageDevice *dev)
 {
   GError *error = NULL;
   FpDeviceVfs5011 *self = FPI_DEVICE_VFS5011 (dev);
+  GUsbDevice *usb_dev = fpi_device_get_usb_device (FP_DEVICE (dev));
 
-  g_usb_device_release_interface (fpi_device_get_usb_device (FP_DEVICE (dev)),
-                                  0, 0, &error);
+  if (usb_dev)
+    g_usb_device_release_interface (usb_dev, 0, 0, &error);
 
-  g_free (self->capture_buffer);
-  g_slist_free_full (g_steal_pointer (&self->rows), g_free);
+  g_clear_pointer (&self->capture_buffer, g_free);
+  g_clear_pointer (&self->init_sequence.receive_buf, g_free);
+  self->lastline = NULL;
+  if (self->rows)
+    {
+      g_slist_free_full (self->rows, g_free);
+      self->rows = NULL;
+    }
 
   fpi_image_device_close_complete (dev, error);
 }
@@ -848,6 +864,7 @@ dev_activate (FpImageDevice *dev)
   self = FPI_DEVICE_VFS5011 (dev);
   fp_dbg ("device initialized");
   self->deactivating = FALSE;
+  self->activated = FALSE;
 
   start_scan (dev);
 }
@@ -858,6 +875,7 @@ dev_deactivate (FpImageDevice *dev)
   FpDeviceVfs5011 *self;
 
   self = FPI_DEVICE_VFS5011 (dev);
+  self->activated = FALSE;
   if (self->loop_running)
     self->deactivating = TRUE;
   else
@@ -888,13 +906,14 @@ fpi_device_vfs5011_class_init (FpDeviceVfs5011Class *klass)
   dev_class->type = FP_DEVICE_TYPE_USB;
   dev_class->id_table = id_table;
   dev_class->scan_type = FP_SCAN_TYPE_SWIPE;
+  dev_class->nr_enroll_stages = 8;
 
   img_class->img_open = dev_open;
   img_class->img_close = dev_close;
   img_class->activate = dev_activate;
   img_class->deactivate = dev_deactivate;
 
-  img_class->bz3_threshold = 20;
+  img_class->bz3_threshold = 10;
 
   img_class->img_width = VFS5011_IMAGE_WIDTH;
   img_class->img_height = -1;
diff --git a/libfprint/fpi-assembling.c b/libfprint/fpi-assembling.c
index 9364685f..6797d82f 100644
--- a/libfprint/fpi-assembling.c
+++ b/libfprint/fpi-assembling.c
@@ -442,7 +442,8 @@ fpi_assemble_lines (struct fpi_line_asmbl_ctx *ctx,
         row1 = g_slist_next (row1);
     }
 
-  median_filter (offsets, (num_lines / 2) - 1, ctx->median_filter_size);
+  if ((num_lines / 2) - 1 > 0)
+    median_filter (offsets, (num_lines / 2) - 1, ctx->median_filter_size);
 
   fp_dbg ("offsets_filtered: %"G_GINT64_FORMAT, g_get_real_time ());
   for (i = 0; i <= (num_lines / 2) - 1; i++)
diff --git a/libfprint/fpi-print.c b/libfprint/fpi-print.c
index 6c5e20db..81902e79 100644
--- a/libfprint/fpi-print.c
+++ b/libfprint/fpi-print.c
@@ -259,7 +259,7 @@ fpi_print_bz3_match (FpPrint *print_template,
       gint score;
       gstruct = g_ptr_array_index (print_template->prints, i);
       score = bozorth_to_gallery (probe_len, pstruct, gstruct);
-      fp_dbg ("score %d/%d", score, bz3_threshold);
+      g_message ("fprint match: template %d/%d score=%d (threshold=%d)", i + 1, print_template->prints->len, score, bz3_threshold);
 
       if (score >= bz3_threshold)
         return FPI_MATCH_SUCCESS;
EOF

# 7. Configure and Build
log_info "Configuring build with Meson..."
rm -rf builddir
meson setup builddir \
    -Ddrivers=vfs5011 \
    -Dudev_rules=disabled \
    -Dudev_hwdb=disabled \
    -Dintrospection=false \
    -Ddoc=false \
    -Dinstalled-tests=false

log_info "Compiling libfprint with Ninja..."
ninja -C builddir

# 8. Safe Backup and Installation
BACKUP_DIR="/var/backups/libfprint-vfs5011-stock"
$SUDO mkdir -p "$BACKUP_DIR"

if [ -f "$LIB_DIR/libfprint-2.so.2.0.0" ] && [ ! -f "$BACKUP_DIR/libfprint-2.so.2.0.0.stock" ]; then
    log_info "Creating safe backup of original stock library in $BACKUP_DIR..."
    $SUDO cp -v "$LIB_DIR/libfprint-2.so.2.0.0" "$BACKUP_DIR/libfprint-2.so.2.0.0.stock"
fi

# Remove any old .orig files from lib directory that might confuse ldconfig
if [ -f "$LIB_DIR/libfprint-2.so.2.0.0.orig" ]; then
    $SUDO rm -f "$LIB_DIR/libfprint-2.so.2.0.0.orig"
fi

log_info "Stopping fprintd service..."
$SUDO systemctl stop fprintd 2>/dev/null || true

log_info "Deploying patched library to $LIB_DIR..."
$SUDO cp -v builddir/libfprint/libfprint-2.so.2.0.0 "$LIB_DIR/libfprint-2.so.2.0.0"
$SUDO ln -sf libfprint-2.so.2.0.0 "$LIB_DIR/libfprint-2.so.2"
$SUDO ldconfig

log_info "Starting fprintd service..."
$SUDO systemctl restart fprintd

# 9. Verify Installation
echo ""
log_info "Driver fix deployed successfully!"
echo -e "${GREEN}======================================================${RESET}"
echo -e "${BOLD}Next Steps:${RESET}"
echo -e "1. If you had existing prints enrolled, clear them first:"
echo -e "   ${YELLOW}fprintd-delete${RESET}"
echo -e "2. Enroll your finger (the driver now records 8 calibration swipes):"
echo -e "   ${YELLOW}fprintd-enroll${RESET}"
echo -e "3. Test authentication:"
echo -e "   ${YELLOW}fprintd-verify${RESET}"
echo -e "   ${YELLOW}sudo -v${RESET} (swipe when prompted)"
echo -e "${GREEN}======================================================${RESET}"
