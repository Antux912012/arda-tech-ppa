# Validity VFS5011 Fingerprint Reader Linux Fix (`138a:0011`, `138a:0017`, `138a:0018`)

> [!WARNING]
> **EXPERIMENTAL DRIVER FIX**: This project modifies `libfprint` to patch timing, threshold, and USB reset quirks for older Validity VFS5011 swipe sensors. It is experimental and community-maintained. Swipe sensors inherently have varying accuracy based on swipe speed and angle compared to modern touch sensors. A safe uninstall script is included to revert to stock drivers at any time.

An automated fix and installer for the **Validity Sensors, Inc. VFS5011** fingerprint reader on modern Linux distributions (Debian, Ubuntu, Fedora, Arch Linux).

Commonly found on:
* **Lenovo ThinkPad 13 2nd Gen**
* **Lenovo ThinkPad T440, T440p, T440s**
* **Dell Vostro series**
* **HP Pavilion / Envy series**

---

## The Problem with Stock Linux Drivers

Although the `vfs5011` driver is present in upstream `libfprint`, real-world hardware fails due to several architectural bugs:
1. **"Enroll-Swipe-Too-Short" Loop:** The driver hardcoded an arbitrary minimum requirement of 160 lines (`self->lines_recorded < VFS5011_IMAGE_WIDTH`). Normal user swipes across a 1-2mm swipe strip only produce 60–120 lines, causing `fprintd-enroll` to loop and fail indefinitely.
2. **Aggressive Line Dropping & Hesitation Halts:** Adjacent lines were discarded too aggressively (`DIFFERENCE_THRESHOLD = 600`), and any brief swipe hesitation halted capture (`STOP_CHECK_LINES = 50`).
3. **USB Endpoint Stalls:** Consecutive opens and session completions left USB endpoints stalled, producing `Device 138a:0011 is already open` or `transfer timed out`.
4. **Strict Match Rejection (1/10 Match Rate):** The Bozorth3 threshold was locked at `20` with only 5 enrollment stages. Because the narrow strip provides fewer minutiae points, genuine user swipes (scoring 10–14) were falsely rejected 90% of the time.
5. **Memory Safety & Assertion Failures:** Calling `activate_complete` repeatedly during multi-stage enrollment threw GLib assertion failures (`priv->active == FALSE`).

---

## What This Fix Does

* **Relaxes Line Thresholds:** Allows valid swipes down to 40 lines; sets difference threshold to 350 and stop check to 80 lines.
* **Adds Hardware USB Reset (`g_usb_device_reset`):** Flushes the USB controller state on device open, preventing `transfer failed` and `device busy` errors.
* **Calibrates Matching for Swipe Strips:** Lowers Bozorth3 threshold to `10` and increases enrollment stages from 5 to 8, providing an 8-template gallery covering multiple swipe angles and speeds.
* **Fixes Median Filter Underflow:** Prevents integer underflows in `fpi-assembling.c` when processing short swipes.
* **Fixes Multi-Stage Activation:** Guards `activate_complete` so it signals cleanly without corrupting the session state machine.
* **Live Score Logging:** Outputs actual Bozorth matching scores to `journalctl -u fprintd` for complete transparency.

---

## Quick Installation

Run the one-line installer:

```bash
git clone https://github.com/Antux912012/vfs5011-linux-fix.git
cd vfs5011-linux-fix
chmod +x install.sh
sudo ./install.sh
```

### Next Steps after Installation:

1. **Delete any old fingerprint profiles:**
   ```bash
   fprintd-delete
   ```
2. **Enroll your finger:**
   ```bash
   fprintd-enroll
   ```
   *(Swipe naturally across the reader 8 times until completed)*
3. **Verify:**
   ```bash
   fprintd-verify
   ```
4. **Test with `sudo`:**
   ```bash
   sudo ls
   ```

---

## Uninstallation / Revert

To restore your distribution's stock `libfprint` package at any time:

```bash
sudo ./uninstall.sh
```

---

## License

GNU Lesser General Public License (LGPL) v2.1+ (matching upstream `libfprint`).
